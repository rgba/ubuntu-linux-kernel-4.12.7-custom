#ifndef _ASM_X86_TYPES_H
#define _ASM_X86_TYPES_H

#include <asm-generic/types.h>

#endif /* _ASM_X86_TYPES_H */
